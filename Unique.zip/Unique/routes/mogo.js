var mongo_client = require('mongodb').MongoClient;
// Connection URL
var db = mongo_client.connect('mongodb://localhost:27017/test', function (error) {
    console.log(error)
});
console.log("Connected correctly to server");

console.log(db.collection);

// Close connection
db.close();
